#pragma once


#define THREAD_SLEEP 13
#define ANIMATION_FRAME 15
#define COL_BUTTONSELLECTED_RG 100
#define COL_BUTTONSELLECTED_B 120
#define COL_BUTTON_RGB 120
#define COL_MENUBG_RGB 60
#define COL_TEXTNOMAL_RGB 210
#define SIZE_TEXT_W 0
#define SIZE_TEXT_H 30
#define FRAME_MAIN 'm'
#define FRAME_ADD 'a'
#define FRAME_DEL 'd'
#define FRAME_PRINT 'p'
#define FRAME_REPORT 'r'
#define FRAME_GAME 'g'
